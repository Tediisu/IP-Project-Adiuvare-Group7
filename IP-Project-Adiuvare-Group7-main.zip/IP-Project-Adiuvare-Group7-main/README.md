# Adiuvare — Scheduling Planner

Adiuvare is a weekly class-scheduling app. Guests and Google-authenticated users can both create, save, edit, and manage their schedules. Signing in with Google adds the separate ability to import schedule items into Google Calendar.

## Tech stack

- Frontend: React, TypeScript, Vite, React Router
- Backend: FastAPI
- Database: SQLite (`backend/data/adiuvare.db`)
- Authentication / calendar integration: Google OAuth 2.0 and Google Calendar API
- Local development: Docker Compose

## Guest and signed-in access

| Feature | Guest | Google signed-in user |
|---|---:|---:|
| Create, edit, delete schedule items | Yes | Yes |
| Save and reload schedule in this browser | Yes | Yes |
| Export schedule as JSON (`Save As`) | Yes | Yes |
| Save and restore grid settings, title, and theme | Yes, for this guest browser | Yes, synced to the account |
| Import schedule items into Google Calendar | No | Yes |

The normal planner is available to everyone. Guest data is associated with a random, HTTP-only browser cookie. Signed-in data is associated with the Google account and can follow the user across devices. When a guest signs in, the app attempts to carry the guest's schedule into the account if the account does not already have schedule items. Existing account data is not overwritten.

Google Calendar import is a separate feature. The frontend displays a sign-in prompt to guests, and the backend independently checks for a valid Google session before creating Calendar events. Hiding the import form in the frontend is not the only access control.

## Requirements

- Docker Desktop with Docker Compose
- A Google OAuth web client only if you want Google sign-in / Google Calendar import

You do not need to install Node.js, Python, or SQLite when using Docker Compose.

## Run the app

Open a terminal in the project root (the folder containing `docker-compose.yml`).

1. Copy `.env.example` to `.env`.
2. If using Google sign-in, fill in `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` in `.env`. If testing guest mode only, these can remain blank.
3. Start both services:

```bash
docker compose up --build
```

Open the app at **http://localhost:5173**.

Useful endpoints:

- App: http://localhost:5173
- API health: http://localhost:8000/api/health
- API docs: http://localhost:8000/docs

To run in the background:

```bash
docker compose up --build -d
```

To view logs:

```bash
docker compose logs -f
```

To stop:

```bash
docker compose down
```

Schedule data is stored in `backend/data/adiuvare.db`, which is mounted from the host so it survives container restarts. Do not run `docker compose down -v` expecting a reset; to reset local data, stop the app and remove the local `backend/data/adiuvare.db` file (this permanently deletes local schedules and sessions).

## Google OAuth setup

Google sign-in and Calendar import require a Google Cloud OAuth 2.0 Client ID for a **Web application**.

1. Create or select a project in Google Cloud Console.
2. Configure the OAuth consent screen.
3. Create a Web application OAuth client.
4. Add this exact Authorized redirect URI:

   `http://localhost:8000/api/auth/google/callback`

5. Enable the Google Calendar API.
6. Put the client ID and secret in the root `.env` file:

```env
GOOGLE_CLIENT_ID=your-client-id
GOOGLE_CLIENT_SECRET=your-client-secret
GOOGLE_REDIRECT_URI=http://localhost:8000/api/auth/google/callback
FRONTEND_URL=http://localhost:5173
```

7. Rebuild and restart:

```bash
docker compose up --build
```

If you only need guest scheduling, Google OAuth setup is optional. Google Calendar import will remain unavailable until OAuth is configured and the user signs in.

## Run without Docker (development)

Use Node.js 24 (the frontend Docker image uses Node 24) and Python 3.12 or newer.

Backend, from the project root:

```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

In a second terminal:

```bash
cd frontend
npm ci
npm run dev
```

Open http://localhost:5173. Vite proxies `/api` requests to `http://localhost:8000` by default.

## Important project locations

- `backend/app/auth.py`: guest identity, Google sessions, and guest-to-account data adoption
- `backend/app/routers/items.py`: normal schedule CRUD, available to guests and signed-in users
- `backend/app/routers/state.py`: saved app preferences/state
- `backend/app/routers/google_calendar.py`: Google OAuth and authenticated-only Calendar import
- `frontend/src/pages/DashboardPage.tsx`: schedule dashboard and feature wiring
- `frontend/src/components/dashboard/GoogleCalendarModal.tsx`: guest sign-in prompt and signed-in import form

## Troubleshooting

**Frontend opens but API requests fail:** make sure both services are running with `docker compose ps`, then check `http://localhost:8000/api/health`.

**Port 8000 or 5173 is already in use:** set `BACKEND_PORT` or `FRONTEND_PORT` in `.env`, for example `BACKEND_PORT=8001`, then restart Compose. The frontend's internal proxy still targets the backend container on port 8000.

**Google login says OAuth is not configured:** check `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` in the root `.env`, verify the redirect URI exactly matches Google Cloud Console, then rebuild with `docker compose up --build`.

**A guest cannot import into Google Calendar:** this is expected. Guests can use the normal Adiuvare schedule, but must sign in with Google to import events into Google Calendar.
